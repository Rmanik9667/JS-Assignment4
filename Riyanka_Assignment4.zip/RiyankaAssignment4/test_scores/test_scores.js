var names = ["Ben", "Joel", "Judy", "Anne"];
var scores = [88, 98, 77, 88];

var $ = function (id) { return document.getElementById(id); };

function displayResults()
{
	   var sum = 0, average = 0, max = 0, maxIndex = 0;
	   for(var i = 0; i < scores.length; i++)
{
		sum += scores[i];
		if(scores[i] > max)
		{
			max = scores[i];
			maxIndex = i;
		}
}
	average = sum/scores.length;
	average = parseFloat(average.toFixed(2));
	$("results").innerHTML = "<h2>Results</h2><p>Average Score = " + average + "</p><p>High score is = " + names[maxIndex] + " with a score of " + scores[maxIndex];
}
function displayScores()
{
	var table = $("scores_table");
    var tBody = table.tBodies[0];
    if (tBody == undefined) {
        tBody = document.createElement("tBody");
        table.appendChild(tBody);
    }
    for (i = 0; i < scores.length; i++) {
        var row = tBody.insertRow(-1);
        var textNode = document.createTextNode(names[i]);
        var cellNode = row.insertCell(-1);
        cellNode.appendChild(textNode);
        var scoreNode = document.createTextNode(scores[i]);
        var cellNode2 = row.insertCell(-1);
        cellNode2.appendChild(scoreNode);
    }
    
    
    
    /*var resultHtmlString = "<h2>Scores</h2><tr><td><strong>Name</strong></td><td><strong>Score</strong></td></tr>";
	for(var i = 0; i < names.length; i++)
	{
		resultHtmlString = htmlString.concat("<tr><td>" + names[i] + "</td><td>" + scores[i] + "</td></tr>");
	}
	$("scores_table").innerHTML = resultHtmlString;
    */
}
function addScore()
{
	var name = $("name").value;
	var score = $("score").value;
	score = parseInt(score);
	if(name.length==0 || isNaN(score) || score < 0 || score > 100 )
	{
		alert("You must enter a name and a valid score to continue");
	}
	else
	{
		names[names.length] = name;
		scores[scores.length] = score;
	}
	$("name").focus();
}


window.onload = function () {
	$("add").onclick = addScore;
	$("display_results").onclick = displayResults;
	$("display_scores").onclick = displayScores;
    $("name").focus();
};



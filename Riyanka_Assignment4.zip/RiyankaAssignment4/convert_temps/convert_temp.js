"use strict";
var $ = function(id) { return document.getElementById(id); };


var clearTextBoxes = function() {
    $("degrees_entered").value = "";
    $("degrees_computed").value = "";
};

var toFahrenheit = function() {
    $("degree_label_1").firstChild.nodeValue = "Enter C degrees:";
    $("degree_label_2").firstChild.nodeValue = "Degrees Fahrenheit:";
    clearTextBoxes();
    $("degrees_entered").focus();
};

var toCelsius = function() {
    $("degree_label_1").firstChild.nodeValue = "Enter F degrees:";
    $("degree_label_2").firstChild.nodeValue = "Degrees Celsius:";
    clearTextBoxes();
    $("degrees_entered").focus();
};

var convertTemp = function() {
    var degreeVal =  $("degrees_entered").value;
    var tempVal = 0;
    
    if(isNaN(degreeVal)) {
        alert("Please enter a valid value for degree");
    }
    else {
        if ($("to_celsius").checked) {
            tempVal = (degreeVal - 32) * 5 / 9;
        }
        else {
            tempVal = degreeVal * 9 / 5 + 32;
        }
        $("degrees_computed").value = tempVal.toFixed(0);
    }
    $("degrees_entered").focus();
}

window.onload = function() {
    $("convert").onclick = convertTemp;
    $("to_celsius").onclick = toCelsius;
    $("to_fahrenheit").onclick = toFahrenheit;
	$("degrees_entered").focus();
};